package entity;

public enum ID {
    Rectangle, Rectangle2, Player, Bullet1,Bullet3,Flipper
}
